package gosayhello

func SayHello()string{
	return "Hello World, I'm Haris !"
}
package gosayhello

func SayHello(name string)string{
	return "Hello" + name
}
package gosayhello

func SayHello()string{
	return "Hello"
}